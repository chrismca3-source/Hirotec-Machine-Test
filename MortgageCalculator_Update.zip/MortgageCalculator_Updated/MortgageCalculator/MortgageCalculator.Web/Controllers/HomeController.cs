﻿using MortgageCalculator.Web.Repos;
using MortgageCalculator.Web.Services;
using System;
using System.Linq;
using System.Web.Mvc;
using System.Web.Services.Description;

namespace MortgageCalculator.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly IMortgageService _service;

        public HomeController()
        {
            // Dependency injection simulation
            _service = new MortgageService(new MortgageRepo());
        }
        
        public ActionResult Index()
        {
            // This loads your main view (with jQuery UI, dropdowns, etc.)
            return View();
        }
        
        [HttpGet]
        public JsonResult GetActiveMortgages()
        {
            var allMortgages = _service.GetAllMortgages();
            var activeMortgages = allMortgages.Where(m => m.IsActive).ToList();
            return Json(activeMortgages, JsonRequestBehavior.AllowGet);
        }

    }
}
