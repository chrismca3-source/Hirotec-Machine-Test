﻿$(document).ready(function () {
     
    // 1) Fetch active mortgages
    $.ajax({
        url: '/Home/GetActiveMortgages',
        type: 'GET',
        success: function (data) {
            let tableBody = $("#mortgageTable tbody");
            tableBody.empty();

            let mortgageTypes = [];

            $.each(data, function (i, item) {
                tableBody.append(`
                    <tr>
                        <td>${item.Name}</td>
                        <td>${getMortgageTypeName(item.MortgageType)}</td>
                        <td>${item.InterestRate}%</td>
                        <td>${formatDate(item.EffectiveStartDate)}</td>
                        <td>${formatDate(item.EffectiveEndDate)}</td>
                        <td>${item.TermsInMonths}</td>
                    </tr>
                `);

                if (mortgageTypes.indexOf(item.MortgageType) === -1) {
                    mortgageTypes.push(item.MortgageType);
                }
            });
            console.log("Unique mortgage types (numbers):", mortgageTypes);

            //// 2) Autocomplete for Mortgage Types
            //$("#mortgageType").autocomplete({
            //    source: mortgageTypes
            //});
        },
        error: function () {
            alert("Error fetching mortgages.");
        }
    });

    // 3) Loan calculator
    $("#btnCalculate").click(function () {
        let principal = parseFloat($("#loanAmount").val());
        let rate = parseFloat($("#loanRate").val()) / 100 / 12; // monthly
        let years = parseInt($("#loanYears").val());
        let months = years * 12;

        if (isNaN(principal) || isNaN(rate) || isNaN(months)) {
            alert("Please enter valid inputs");
            return;
        }

        // Formula: EMI = P * r * (1+r)^n / ((1+r)^n - 1)
        let emi = principal * rate * Math.pow(1 + rate, months) / (Math.pow(1 + rate, months) - 1);
        let totalRepayment = emi * months;
        let interestPaid = totalRepayment - principal;

        $("#totalRepayment").text(totalRepayment.toFixed(2));
        $("#interestPaid").text(interestPaid.toFixed(2));
    });
    // Map enum integers to names
    function getMortgageTypeName(value) {
        switch (value) {
            case 0: return "Fixed";
            case 1: return "Variable";
            default: return "Unknown";
        }
    }

    function getInterestRepaymentName(value) {
        switch (value) {
            case 0: return "PrincipalOnly";
            case 1: return "InterestOnly";
            default: return "Unknown";
        }
    }
    function formatDate(dateStr) {
        if (!dateStr) return "";
        const timestamp = parseInt(dateStr.replace("/Date(", "").replace(")/", ""));
        const date = new Date(timestamp);
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }
    function calculateEMI() {
        var P = parseFloat($('#loanAmount').val());
        var R = parseFloat($('#interestRate').val()) / 100 / 12;
        var N = parseInt($('#tenure').val()) * 12;

        var EMI = (P * R * Math.pow(1 + R, N)) / (Math.pow(1 + R, N) - 1);
        if (isNaN(EMI)) EMI = 0;

        var totalAmt = EMI * N;
        var interestAmt = totalAmt - P;

        $('#emiAmount').text('₹' + Math.round(EMI).toLocaleString());
        $('#principalAmt').text(P.toLocaleString());
        $('#interestAmt').text(Math.round(interestAmt).toLocaleString());
        $('#totalAmt').text(Math.round(totalAmt).toLocaleString());
    }

    // Sync sliders and input
    $('#loanAmount, #loanAmountSlider').on('input', function () {
        var val = $(this).val();
        $('#loanAmount').val(val);
        $('#loanAmountSlider').val(val);
        calculateEMI();
    });

    $('#interestRate, #interestRateSlider').on('input', function () {
        var val = $(this).val();
        $('#interestRate').val(val);
        $('#interestRateSlider').val(val);
        calculateEMI();
    });

    $('#tenure, #tenureSlider').on('input', function () {
        var val = $(this).val();
        $('#tenure').val(val);
        $('#tenureSlider').val(val);
        calculateEMI();
    });

    // Autocomplete mortgage types
    var mortgageTypes = [];
    $.ajax({
        url: '/Mortgage/GetActiveMortgages',
        type: 'GET',
        success: function (data) {
            mortgageTypes = data.map(x => x.Type).sort();
            $("#mortgageType").autocomplete({
                source: mortgageTypes
            });
        }
    });

    // Initial calculation
    calculateEMI();
   

});
