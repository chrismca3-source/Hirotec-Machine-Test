﻿using MortgageCalculator.Dto;
using System.Collections.Generic;
using System.Data.Entity;

namespace MortgageCalculator.Web.Data
{
    public class MortgageDataContext : DbContext
    {
        public MortgageDataContext() : base("name=MortgageConnection") { }

        public DbSet<Mortgage> Mortgages { get; set; }
    }
}