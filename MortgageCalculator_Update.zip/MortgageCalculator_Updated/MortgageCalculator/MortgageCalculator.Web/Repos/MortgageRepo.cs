﻿using MortgageCalculator.Dto;
using MortgageCalculator.Web.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MortgageCalculator.Web.Repos
{
    public interface IMortgageRepo
    {
        List<Mortgage> GetAllMortgages();
    }

    public class MortgageRepo : IMortgageRepo
    {
        private readonly MortgageDataContext _context;

        public MortgageRepo()
        {
            _context = new MortgageDataContext();
        }

        public List<Mortgage> GetAllMortgages()
        {
            using (var context = new MortgageDataContext())
            {
                var result = context.Database.SqlQuery<Mortgage>(
                    "EXEC dbo.sp_GetActiveMortgages"
                ).ToList();

                return result;
            }
        }





    }
}