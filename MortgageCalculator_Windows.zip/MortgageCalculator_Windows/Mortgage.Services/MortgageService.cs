﻿using Mortgage.Data;
using Mortgage.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace Mortgage.Services
{
    public class MortgageService
    {
        private readonly MortgageDataContext _context;

        public MortgageService(MortgageDataContext context)
        {
            _context = context;
        }

        public List<MortgageEntity> GetActiveMortgagesFromSP()
        {
            // Using FromSqlRaw to call stored procedure
            return _context.Mortgages
                           .FromSqlRaw("EXEC dbo.sp_GetActiveMortgages")
                           .ToList();

        }

        public (decimal totalRepayment, decimal totalInterest) CalculateMortgage(decimal principal, double annualRate, int years)
        {
            double monthlyRate = annualRate / 100 / 12;
            int months = years * 12;

            double monthlyPayment = (double)principal * (monthlyRate * Math.Pow(1 + monthlyRate, months)) /
                                    (Math.Pow(1 + monthlyRate, months) - 1);

            decimal totalRepayment = (decimal)(monthlyPayment * months);
            decimal totalInterest = totalRepayment - principal;

            return (totalRepayment, totalInterest);
        }
    }
}
