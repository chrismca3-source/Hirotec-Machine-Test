﻿namespace Mortgage.Services
{
    public class Class1
    {

    }
}
