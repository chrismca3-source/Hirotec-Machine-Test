﻿namespace Mortgage.Data
{
    public class Class1
    {

    }
}
