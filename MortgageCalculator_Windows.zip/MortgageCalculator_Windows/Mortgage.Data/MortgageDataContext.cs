﻿using Microsoft.EntityFrameworkCore;
using Mortgage.Data.Models;

namespace Mortgage.Data
{
    public class MortgageDataContext : DbContext
    {
        public DbSet<MortgageEntity> Mortgages { get; set; }

        public MortgageDataContext(DbContextOptions<MortgageDataContext> options)
            : base(options) { }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Mark the entity as keyless if the SP doesn't return a primary key
            modelBuilder.Entity<MortgageEntity>().HasNoKey();

            base.OnModelCreating(modelBuilder);
        }
    }
}
