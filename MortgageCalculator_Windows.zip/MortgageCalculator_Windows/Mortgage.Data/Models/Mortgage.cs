﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mortgage.Data.Models
{

    public class MortgageEntity
    {
        public int MortgageId { get; set; }
        [Browsable(false)]
        public int MortgageType { get; set; } = 0;
        [DisplayName("Interest Rate %")]
        public decimal InterestRate { get; set; }
        [DisplayName("Mortgage Type")]
        public string TypeName
        {
            get
            {
                return MortgageType switch
                {
                    0 => "Fixed",
                    1 => "Variable",
                    _ => "Unknown"
                };
            }
        }
        [DisplayName("Active Status")]
        public bool IsActive { get; set; }
        
    }


}
