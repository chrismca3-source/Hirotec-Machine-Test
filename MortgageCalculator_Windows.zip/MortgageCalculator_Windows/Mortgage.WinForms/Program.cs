using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Mortgage.Data;
using Mortgage.Services;

namespace Mortgage.WinForms
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            var services = new ServiceCollection();

            services.AddDbContext<MortgageDataContext>(options =>
                options.UseSqlServer(
                    @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=MortgageDB;Integrated Security=True;Persist Security Info=False;Pooling=False;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Application Name=SQL Server Management Studio;Command Timeout=30"
                )
            );

            services.AddScoped<MortgageService>();

            using var provider = services.BuildServiceProvider();
            var service = provider.GetRequiredService<MortgageService>();

            ApplicationConfiguration.Initialize();
            Application.Run(new Form1(service));
        }
    }
}
