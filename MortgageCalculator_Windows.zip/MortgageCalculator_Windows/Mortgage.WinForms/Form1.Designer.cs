﻿using System.Windows.Forms.DataVisualization.Charting;

namespace Mortgage.WinForms
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private Chart chartPrincipalInterest;

        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            txtLoanAmount = new TextBox();
            txtInterestRate = new TextBox();
            txtYears = new TextBox();
            btnCalculate = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            lblTotalInterest = new Label();
            lblTotalRepayment = new Label();
            comboBoxType = new ComboBox();
            panelInputs = new Panel();
            panelResults = new Panel();

            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panelInputs.SuspendLayout();
            panelResults.SuspendLayout();
            SuspendLayout();

            // ----------------------
            // Main Form
            // ----------------------
            BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            ClientSize = new System.Drawing.Size(1280, 750);
            Font = new System.Drawing.Font("Segoe UI", 10F);
            Text = "Mortgage Calculator";
            Name = "Form1";

            // ----------------------
            // DataGridView
            // ----------------------
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeight = 30;
            dataGridView1.Location = new System.Drawing.Point(50, 12);
            dataGridView1.Size = new System.Drawing.Size(1180, 200);
            dataGridView1.BackgroundColor = System.Drawing.Color.White;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(0, 120, 215);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);

            // ----------------------
            // Input Panel
            // ----------------------
            panelInputs.BackColor = System.Drawing.Color.White;
            panelInputs.BorderStyle = BorderStyle.FixedSingle;
            panelInputs.Location = new System.Drawing.Point(50, 230);
            panelInputs.Size = new System.Drawing.Size(380, 450);
            panelInputs.Padding = new Padding(20);
            panelInputs.Controls.Add(label1);
            panelInputs.Controls.Add(comboBoxType);
            panelInputs.Controls.Add(label2);
            panelInputs.Controls.Add(txtLoanAmount);
            panelInputs.Controls.Add(label3);
            panelInputs.Controls.Add(txtInterestRate);
            panelInputs.Controls.Add(label4);
            panelInputs.Controls.Add(txtYears);
            panelInputs.Controls.Add(btnCalculate);

            // ----------------------
            // Labels and TextBoxes
            // ----------------------
            label1.Text = "Mortgage Type";
            label1.Font = new System.Drawing.Font("Segoe UI Semibold", 11F);
            label1.Location = new System.Drawing.Point(20, 10);

            comboBoxType.Location = new System.Drawing.Point(20, 40);
            comboBoxType.Size = new System.Drawing.Size(320, 32);
            comboBoxType.Font = new System.Drawing.Font("Segoe UI", 10F);

            label2.Text = "Loan Amount (₹)";
            label2.Font = new System.Drawing.Font("Segoe UI Semibold", 11F);
            label2.Location = new System.Drawing.Point(20, 85);

            txtLoanAmount.Location = new System.Drawing.Point(20, 115);
            txtLoanAmount.Size = new System.Drawing.Size(320, 32);
            txtLoanAmount.Font = new System.Drawing.Font("Segoe UI", 10F);

            label3.Text = "Interest Rate (%)";
            label3.Font = new System.Drawing.Font("Segoe UI Semibold", 11F);
            label3.Location = new System.Drawing.Point(20, 160);

            txtInterestRate.Location = new System.Drawing.Point(20, 190);
            txtInterestRate.Size = new System.Drawing.Size(320, 32);

            label4.Text = "Tenure (Years)";
            label4.Font = new System.Drawing.Font("Segoe UI Semibold", 11F);
            label4.Location = new System.Drawing.Point(20, 235);

            txtYears.Location = new System.Drawing.Point(20, 265);
            txtYears.Size = new System.Drawing.Size(320, 32);

            // ----------------------
            // Calculate Button
            // ----------------------
            btnCalculate.Text = "Calculate";
            btnCalculate.BackColor = System.Drawing.Color.FromArgb(0, 120, 215);
            btnCalculate.ForeColor = Color.White;
            btnCalculate.FlatStyle = FlatStyle.Flat;
            btnCalculate.FlatAppearance.BorderSize = 0;
            btnCalculate.Size = new System.Drawing.Size(150, 40);
            btnCalculate.Location = new System.Drawing.Point(95, 320);
            btnCalculate.Font = new System.Drawing.Font("Segoe UI Semibold", 11F);
            btnCalculate.Cursor = Cursors.Hand;
            btnCalculate.Click += btnCalculate_Click;

            // ----------------------
            // Results Panel
            // ----------------------
            panelResults.BackColor = Color.White;
            panelResults.BorderStyle = BorderStyle.FixedSingle;
            panelResults.Location = new System.Drawing.Point(460, 230);
            panelResults.Size = new System.Drawing.Size(770, 450);
            panelResults.Padding = new Padding(20);
            panelResults.Controls.Add(lblTotalRepayment);
            panelResults.Controls.Add(lblTotalInterest);

            // Total Repayment Label
            lblTotalRepayment.Text = "Total Repayment: ₹0";
            lblTotalRepayment.Font = new System.Drawing.Font("Segoe UI Semibold", 14F);
            lblTotalRepayment.ForeColor = Color.FromArgb(0, 120, 215);
            lblTotalRepayment.Location = new System.Drawing.Point(20, 20);
            lblTotalRepayment.AutoSize = true;

            // Total Interest Label
            lblTotalInterest.Text = "Total Interest: ₹0";
            lblTotalInterest.Font = new System.Drawing.Font("Segoe UI Semibold", 14F);
            lblTotalInterest.ForeColor = Color.FromArgb(230, 50, 50);
            lblTotalInterest.Location = new System.Drawing.Point(20, 60);
            lblTotalInterest.AutoSize = true;

            // ----------------------
            // Form Controls
            // ----------------------
            Controls.Add(dataGridView1);
            Controls.Add(panelInputs);
            Controls.Add(panelResults);
            BackColor = Color.FromArgb(245, 247, 250);

            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panelInputs.ResumeLayout(false);
            panelInputs.PerformLayout();
            panelResults.ResumeLayout(false);
            panelResults.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView1;
        private TextBox txtLoanAmount;
        private TextBox txtInterestRate;
        private TextBox txtYears;
        private Button btnCalculate;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label lblTotalInterest;
        private Label lblTotalRepayment;
        private ComboBox comboBoxType;
        private Panel panelInputs;
        private Panel panelResults;
    }
}
