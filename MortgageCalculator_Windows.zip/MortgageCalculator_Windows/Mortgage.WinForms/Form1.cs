﻿using System;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using Microsoft.EntityFrameworkCore;
using Mortgage.Data;
using Mortgage.Services;

namespace Mortgage.WinForms
{
    public partial class Form1 : Form
    {
        private readonly MortgageService _service;
        private Chart chartMortgage; // chart field

        public Form1(MortgageService service)
        {
            InitializeComponent();
            _service = service;
            InitializeChart();   // setup chart inside panelResults
            LoadActiveMortgages();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadActiveMortgages();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal principal = decimal.Parse(txtLoanAmount.Text);
            double rate = double.Parse(txtInterestRate.Text);
            int years = int.Parse(txtYears.Text);

            var result = _service.CalculateMortgage(principal, rate, years);

            lblTotalRepayment.Text = $"Total Repayment: {result.totalRepayment:C}";
            lblTotalInterest.Text = $"Total Interest: {result.totalInterest:C}";

            // Update chart
            UpdatePrincipalInterestChart(principal, result.totalInterest);
        }

        private MortgageDataContext CreateDbContext()
        {
            var options = new DbContextOptionsBuilder<MortgageDataContext>()
                .UseSqlServer(
                    @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=MortageCalculator;Integrated Security=True;",
                    sqlServerOptions => sqlServerOptions.EnableRetryOnFailure(5, TimeSpan.FromSeconds(2), null)
                )
                .Options;

            return new MortgageDataContext(options);
        }

        private void LoadActiveMortgages()
        {
            using var context = CreateDbContext();
            MortgageService service = new MortgageService(context);
            var mortgages = service.GetActiveMortgagesFromSP();

            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = mortgages;

            // Populate ComboBox
            comboBoxType.DataSource = mortgages.Select(m => m.TypeName).Distinct().ToList();
            comboBoxType.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            comboBoxType.AutoCompleteSource = AutoCompleteSource.ListItems;
        }

        // ======================
        // Chart Setup
        // ======================
        private void InitializeChart()
        {
            chartMortgage = new Chart();
            chartMortgage.Size = new System.Drawing.Size(300, 250);
            chartMortgage.Dock = DockStyle.Right; // align inside panelResults on right side

            ChartArea chartArea = new ChartArea("MainArea");
            chartMortgage.ChartAreas.Add(chartArea);

            Series series = new Series("Mortgage Breakdown");
            series.ChartType = SeriesChartType.Pie;
            chartMortgage.Series.Add(series);
            series.Points.Clear();
            chartMortgage.Legends.Add(new Legend("Legend"));

            // Add to panelResults (instead of the form)
            panelResults.Controls.Add(chartMortgage);
        }

        private void UpdatePrincipalInterestChart(decimal principal, decimal interest)
        {
            var series = chartMortgage.Series["Mortgage Breakdown"];
            series.Points.Clear();

            series.Points.AddXY("Principal", (double)principal);
            series.Points.AddXY("Interest", (double)interest);

            series.Points[0].Color = System.Drawing.Color.SteelBlue;
            series.Points[1].Color = System.Drawing.Color.OrangeRed;

             
        }
    }
}
